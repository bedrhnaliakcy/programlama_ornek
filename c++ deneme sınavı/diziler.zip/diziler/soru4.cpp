#include <iostream>
#include <cstring>
using namespace std;
int main(){
	char cumle[20];
	cout << "bir cumle giriniz:  ";
	gets(cumle);
	puts(cumle);
	system("PAUSE");
	return 0;
}
