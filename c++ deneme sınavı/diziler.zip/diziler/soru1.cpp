#include <iostream>
using namespace std;
int main(){
	int arr[8]={1,2,3,4,5,6,7,8};
	for(int i=0;i<8;i++){
		cout << i << ". indeks degeri:\t" << arr[i] << endl;
	}
	system("PAUSE");
	return 0;
}
